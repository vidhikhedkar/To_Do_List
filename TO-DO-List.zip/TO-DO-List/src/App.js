import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./Home";
import Favourites from "./Favourite";
import "./index.css";

const tasksList = ["Waking up in the morning", "Study time", "lunch time", "Ramya", "Monica"];

const App = () => {
  const [tasks, setStudents] = useState(tasksList);
  const [favorites, setFavorites] = useState([]);
  const [darkMode, setDarkMode] = useState(false);

  const addToFavorites = (student) => {
    setFavorites([...favorites, student]);
    setStudents(tasks.filter((s) => s !== student));
  };

  const removeFromFavorites = (student) => {
    setStudents([...tasks, student]);
    setFavorites(favorites.filter((s) => s !== student));
  };

  return (
    <div className={darkMode ? "dark-mode" : "light-mode"}>
      <Router>
        <button className="toggle-btn" onClick={() => setDarkMode(!darkMode)}>
          {darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
        </button>
        <Routes>
          <Route path="/" element={<Home students={tasks} addToFavorites={addToFavorites} />} />
          <Route path="/favourites" element={<Favourites favorites={favorites} removeFromFavorites={removeFromFavorites} />} />
        </Routes>
      </Router>
    </div>
  );
};

export default App;
